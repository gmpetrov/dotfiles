from scrap import Scrapper
import threading

scrapper = Scrapper();

scrapper.scrap(160, "casque", "schuberth");
scrapper.scrap(35, "gants", "furygan");
#scrapper.scrap(180, "cuir", "alpinestars");
scrapper.scrap(50, "mstand");
scrapper.scrap(100, "bose", "qc", "25");
scrapper.scrap(800, "thinkpad", "Y50");
scrapper.scrap(800, "thinkpad", "i7");
scrapper.scrap(160, "oneplus", "one");

