import urllib, json

def isServerAvailable(reference):
    url = "https://ws.ovh.com/dedicated/r2/ws.dispatcher/getAvailability2"
    response = urllib.urlopen(url)
    data = json.loads(response.read())

    for availability in data['answer']['availability']:
        if availability['reference'] == reference:
            for zone in availability['metaZones']:
                if zone['availability'] != "unavailable" and zone['availability'] != "unknown":
                    return True
    return False
                
