from params import *
from urllib2 import urlopen
import bs4 as BeautifulSoup
import re
import smtplib
from firebase import firebase
import json
from email.MIMEMultipart import MIMEMultipart
from email.MIMEText import MIMEText

import urllib2

from isServerAvailable import isServerAvailable

GLOBALS = Globals();

class Scrapper:

    # Send a mail when there is a match
    def sendMail(self, title):

        fromaddr = GLOBALS.smtpServerLogin;
        toaddr   = GLOBALS.smtpServerRecipient;
        msg = MIMEMultipart();        
        msg['From'] = fromaddr;
        msg['To'] = toaddr;
        msg['Subject'] = title;

        body = "Kim sufi server dispo";
        msg.attach(MIMEText(body.encode('utf-8'), 'plain'));

        # Init the smtp server
        server = smtplib.SMTP('smtp.gmail.com', 587);
        server.starttls()
        server.login(fromaddr, GLOBALS.smtpServerPasswd)  

        # Send the mail
        server.sendmail(fromaddr, toaddr, msg.as_string())

        # quit smtp server
        server.quit()

        # Send sms
        self.sendSms(body);

    # Send an sms
    def sendSms(self, msg):
        msg = msg.split(' ');
        msg = "+".join(msg);
        freeMobileApi = "https://smsapi.free-mobile.fr/sendmsg?user=15541580&pass=tRTmJRVQ2jC9BE&msg=";
        urllib2.urlopen(freeMobileApi + msg.encode('utf-8'));

    def scrap(self):

        ref = "160sk1"

        if (isServerAvailable(ref) == True):
            self.sendMail("Kimsufi Server Available : " + ref)

scrapper = Scrapper();
scrapper.scrap();
