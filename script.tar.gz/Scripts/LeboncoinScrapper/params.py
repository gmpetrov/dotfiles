class Globals():
    smtpServerLogin     = "alert.gmp@gmail.com";
    smtpServerPasswd    = "Gmpgmp1989";
    smtpServerRecipient = "georgesm.petrov@gmail.com"
    firebaseAppUrl      = "https://alert-gmp.firebaseio.com"
